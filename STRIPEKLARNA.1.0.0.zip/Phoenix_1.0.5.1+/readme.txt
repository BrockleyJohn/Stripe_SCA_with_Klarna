Installation instructions and user guide at
https://cartmart.uk/klarna-stripe-payment-module-p-5.html
